import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONObject; //se necesita descargar este archivo para usar los JSON. no olvidar sino dara como 6 errores sobre JSON

public class Main {

    // Tu API Key
    private static final String API_KEY = "bae6f723eb63dee8c684672d";
    private static final String API_URL = "https://v6.exchangerate-api.com/v6/" + API_KEY + "/latest/USD";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            // Menú
            System.out.println("\nSea bienvenido/a al Conversor de monedas de Kevin");
            System.out.println("1) Dólar -> Peso argentino");
            System.out.println("2) Peso argentino -> Dólar");
            System.out.println("3) Dólar -> Real brasileño");
            System.out.println("4) Real brasileño -> Dólar");
            System.out.println("5) Dólar -> Peso colombiano");
            System.out.println("6) Peso colombiano -> Dólar");
            System.out.println("7) Salir");
            System.out.print("Elija una opción válida: ");

            opcion = sc.nextInt();

            switch(opcion) {
                case 1:
                    convertir(sc, "USD", "ARS");
                    break;
                case 2:
                    convertir(sc, "ARS", "USD");
                    break;
                case 3:
                    convertir(sc, "USD", "BRL");
                    break;
                case 4:
                    convertir(sc, "BRL", "USD");
                    break;
                case 5:
                    convertir(sc, "USD", "COP");
                    break;
                case 6:
                    convertir(sc, "COP", "USD");
                    break;
                case 7:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida, intente de nuevo.");
            }

        } while(opcion != 7);

        sc.close();
    }

    private static void convertir(Scanner sc, String from, String to) {
        try {
            System.out.print("Ingresa la cantidad que deseas convertir: ");
            double cantidad = sc.nextDouble();

            double tasa = obtenerTasa(from, to);
            double resultado = cantidad * tasa;

            System.out.printf("El valor de %.2f %s corresponde a %.2f %s%n", cantidad, from, resultado, to);

        } catch (Exception e) {
            System.out.println("Error al realizar la conversión: " + e.getMessage());
        }
    }

    private static double obtenerTasa(String from, String to) throws Exception {
        // Para conversiones inversas, usamos USD como base
        String urlStr = API_URL;
        JSONObject json = leerJson(urlStr);

        JSONObject rates = json.getJSONObject("conversion_rates");

        if(from.equals("USD")) {
            return rates.getDouble(to);
        } else if(to.equals("USD")) {
            return 1 / rates.getDouble(from);
        } else {
            // Conversion entre monedas que no sean USD
            double usdToFrom = 1 / rates.getDouble(from);
            double usdToTo = rates.getDouble(to);
            return usdToFrom * usdToTo;
        }
    }

    private static JSONObject leerJson(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuilder content = new StringBuilder();

        while ((inputLine = in.readLine()) != null) {
            content.append(inputLine);
        }

        in.close();
        conn.disconnect();

        return new JSONObject(content.toString());
    }
}
